<?php
session_start();
//print_r($_SESSION);
$search=$_REQUEST["search"];
$action=$_REQUEST["action"];
/* connect to the db */
	$link = mysql_connect('localhost','root','') or die('Cannot connect to the DB');
	mysql_select_db('healthmonitoring',$link) or die('Cannot select the DB');

	/* grab the posts from the db */
if($search=="")
{
$query = "SELECT pid,pname,pprice,pqty,mobilenum,name from product p , login l where  l.aadhar_num=p.pauthor ";
}
else
{
	$query = "SELECT pid,pname,pprice,pqty,mobilenum,name from product p , login l where  l.aadhar_num=p.pauthor and  pname like '%".$search."%'";
}
//$query = "SELECT * from doctor";
//$query = "SELECT * from doctor ";
$result = mysql_query($query,$link) or die('Errant query:  '.$query);

	/* create one master array of the records */
	$posts = array();
	if(mysql_num_rows($result)) {
		while($row = mysql_fetch_assoc($result)) {
			$posts[] = array(
				'pid' => $row['pid'],
      'product_name' => $row['pname'],
      'product_price' => $row['pprice'],
      'product_qty' => $row['pqty'],
				   'mobilenum' => $row['mobilenum'],
				   'name' => $row['name']
				//'ut'=>$_SESSION['usertype']


   );

		}

	}

/*$html="";
	$html=$html."<table border=1>";
$html=$html."<tr><th >Medical NUmber</th><th >Doctor First Name</th><th >Doctor Last Name</th><th >Mobile Number</th><th >Specialization</th><th >hospital</th></tr>";


while($row = mysql_fetch_array($result, MYSQL_ASSOC)) {

$html=$html."<tr><td>".$row['doc_medical_no']."</td>";
$html=$html."<td>".$row['doc_fname']."</td>";
$html=$html."<td>".$row['doc_lname']."</td>";
$html=$html."<td>".$row['doc_mob']."</td>";
$html=$html."<td>".$row['doc_specialization']."</td>";
$html=$html."<td>".$row['doc_hospital']."</td></tr>";
		}
	


$html=$html."<table>";*/

	/* output in necessary format */
	//if($format == 'json') {
		//header('Content-type: application/json');
$return["json"] =json_encode($posts);
//echo json_encode(array('posts'=>$posts));
echo json_encode($posts);
	//}

//echo $html;

?>

