<?php
include('db.php');
$data[] = array('Day','Level');
session_start();
$sql = "select * from bp_level where patient_id='".$_SESSION['patient_id']."'";
$query = mysql_query($sql);
while($result = mysql_fetch_array($query))
{
$data[] = array($result['day'],(int)$result['level']);
  
}




//	$data = array($data);			
echo json_encode($data);
?>
