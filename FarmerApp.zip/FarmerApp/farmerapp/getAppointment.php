<?php
include("config.php");
session_start();
$aadhar_num= $_SESSION['login_user'];
$doc_id=$_REQUEST["doc_id"];
$comments=$_REQUEST["comments"];
/*$sql1 = "SELECT * from appointment  where doc_id='".$doc_id."' &&  patient_id='".$aadhar_num."'";
$result = mysqli_query($db,$sql1);
 $row = mysqli_fetch_array($result,MYSQLI_ASSOC);
     
     
      $count = mysqli_num_rows($result);
if($count==0)
{
$sql = "insert into appointment  values('','".$doc_id."' , '".$aadhar_num."','NA','".$comments."',NULL,NULL,NULL,NULL,NULL)";
$result = mysqli_query($db,$sql);
if($result)
{
  //header("location: success.html");
$posts[] = array('status' => '1');

}
else
{
 // header("location: failure.html");
$posts[] = array('status' => '0');

}
}
else
{
$posts[] = array('status' => '0');
}*/
$sql = "update  product  set  pqty='".$comments."' where pid='".$doc_id."'";
$result = mysqli_query($db,$sql);
if($result)
{
  //header("location: success.html");
$posts[] = array('status' => '1');

}
else
{
 // header("location: failure.html");
$posts[] = array('status' => '0');

}
echo json_encode($posts);
?>