<?php
include("config.php");
$name= $_REQUEST['name'];
$email=$_REQUEST["email"];
$user=$_REQUEST["user"];
$password=$_REQUEST["pass"];
$cpassword=$_REQUEST["cpass"];
$mobile=$_REQUEST["pno"];
$usertype=$_REQUEST["ut"];

$sql = "insert into login  values('".$name."','".$email."','".$user."','".$password."','".$mobile."','".$usertype."',NULL,now(),NULL,now(),NULL,NULL,NULL,NULL,NULL)";
//echo $sql;
$result = mysqli_query($db,$sql);
if($result)
{
  //header("location: success.html");
$posts[] = array('status' => '1');
echo "YOUR REGISTRATION IS COMPLETED...";
echo " <a href='index.html'>BACK</a>";

}
else
{
 // header("location: failure.html");
$posts[] = array('status' => '0');
echo "SORRY...PROBLEM IN  REGISTERING THE USER...";
echo " <a href='index.html'>BACK</a>";

}

//echo json_encode($posts);
?>