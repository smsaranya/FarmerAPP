<?php
include("config.php");
session_start();
$aadhar_num= $_SESSION['login_user'];
$productname= $_REQUEST['p-name'];
$productprice=$_REQUEST["p-price"];
$productqty=$_REQUEST["p-qty"];

$sql = "insert into product (pname,pprice,pqty,pauthor) values ('".$productname."','".$productprice."','".$productqty."','".$aadhar_num."')";  
//echo $sql;
$result = mysqli_query($db,$sql);
if($result)
{
  //header("location: success.html");
$posts[] = array('status' => '1');
echo "YOUR Product has been Added...";
echo " <a href='index.html'>BACK</a>";

}
else
{
 // header("location: failure.html");
$posts[] = array('status' => '0');
echo "SORRY...PROBLRM IN ADDING PRODUCT...";
echo " <a href='addproduct.html'>BACK</a>";

}

//echo json_encode($posts);
?>