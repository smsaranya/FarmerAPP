<?php
include('db.php');
session_start();
$sql = "select * from bp_level where patient_id='".$_SESSION['patient_id']."'";
echo $sql;
$query = mysql_query($sql);
while($result = mysql_fetch_array($query))
{
  $rows[]=array("c"=>array("0"=>array("v"=>$result['day'],"f"=>NULL),"1"=>array("v"=>(int)$result['level'],"f" =>NULL)));
  
}

echo $format = '{
"cols":
[
{"id":"","label":"day","pattern":"","type":"string"},
{"id":"","label":"level","pattern":"","type":"number"}
],
"rows":'.json_encode($rows).'}';

	

?>








