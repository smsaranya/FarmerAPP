
	

<?php
//session_start();
$doc_id=$_SESSION['login_user'];
//print_r($_SESSION);
//$search=$_REQUEST["search"];
//$ction=$_REQUEST["action"];
/* connect to the db */
	$link = mysql_connect('localhost','root','') or die('Cannot connect to the DB');
	mysql_select_db('healthmonitoring',$link) or die('Cannot select the DB');

	/* grab the posts from the db */
	//$query = "SELECT patient_id from appointemnt where doc_id='".$search."'";
$query = "SELECT patient_id,doc_id,t1.custom0 as pblm,t2.custom0 as pname,appointment_status from appointment t1, patient_login t2 where t1.patient_id=t2.aadhar_num  and  doc_id='".$doc_id."' ";
//$query = "SELECT * from doctor";
//$query = "SELECT * from doctor ";
$result = mysql_query($query,$link) or die('Errant query:  '.$query);

	/* create one master array of the records */
	$posts = array();
	if(mysql_num_rows($result)) {
		while($row = mysql_fetch_assoc($result)) {
			$posts[] = array(
      'patient_id' => $row['patient_id'],
'patient_name' => $row['pname'],
'status' => $row['appointment_status'],
'pblm' => $row['pblm'],
'doc_id'=>$row['doc_id']
   );

		}

	}

/*$html="";
	$html=$html."<table border=1>";
$html=$html."<tr><th >Medical NUmber</th><th >Doctor First Name</th><th >Doctor Last Name</th><th >Mobile Number</th><th >Specialization</th><th >hospital</th></tr>";


while($row = mysql_fetch_array($result, MYSQL_ASSOC)) {

$html=$html."<tr><td>".$row['doc_medical_no']."</td>";
$html=$html."<td>".$row['doc_fname']."</td>";
$html=$html."<td>".$row['doc_lname']."</td>";
$html=$html."<td>".$row['doc_mob']."</td>";
$html=$html."<td>".$row['doc_specialization']."</td>";
$html=$html."<td>".$row['doc_hospital']."</td></tr>";
		}
	


$html=$html."<table>";*/

	/* output in necessary format */
	//if($format == 'json') {
		//header('Content-type: application/json');
$return["json"] =json_encode($posts);
//echo json_encode(array('posts'=>$posts));
echo json_encode($posts);
	//}

//echo $html;

?>

