-- phpMyAdmin SQL Dump
-- version 3.3.9
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jul 31, 2017 at 01:41 AM
-- Server version: 5.1.53
-- PHP Version: 5.3.4

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `healthmonitoring`
--

-- --------------------------------------------------------

--
-- Table structure for table `appointment`
--

CREATE TABLE IF NOT EXISTS `appointment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `doc_id` varchar(50) NOT NULL,
  `patient_id` varchar(50) NOT NULL,
  `appointment_status` varchar(50) DEFAULT NULL,
  `custom0` varchar(50) DEFAULT NULL,
  `custom1` varchar(50) DEFAULT NULL,
  `custom2` varchar(50) DEFAULT NULL,
  `custom3` varchar(50) DEFAULT NULL,
  `custom4` varchar(50) DEFAULT NULL,
  `custom5` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=21 ;

--
-- Dumping data for table `appointment`
--

INSERT INTO `appointment` (`id`, `doc_id`, `patient_id`, `appointment_status`, `custom0`, `custom1`, `custom2`, `custom3`, `custom4`, `custom5`) VALUES
(19, '1234', '1234567856781234', 'A', 'nerve problem', NULL, NULL, NULL, NULL, NULL),
(20, '1256', '5678123412345678', 'NA', 'test', NULL, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `bp_level`
--

CREATE TABLE IF NOT EXISTS `bp_level` (
  `patient_id` varchar(50) NOT NULL,
  `day` varchar(50) NOT NULL,
  `level` int(11) NOT NULL,
  `created_on` varchar(50) DEFAULT NULL,
  `created_by` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `bp_level`
--

INSERT INTO `bp_level` (`patient_id`, `day`, `level`, `created_on`, `created_by`) VALUES
('1234567856781234', 'Monday', 80, NULL, NULL),
('1234567856781234', 'Tuesday', 110, NULL, NULL),
('1234567856781234', 'Wednesday', 120, NULL, NULL),
('1234567856781234', 'Thursday', 90, NULL, NULL),
('1234567890', 'Friday', 78, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `courses`
--

CREATE TABLE IF NOT EXISTS `courses` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `subject` varchar(20) NOT NULL,
  `number` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `courses`
--

INSERT INTO `courses` (`id`, `subject`, `number`) VALUES
(1, 'PHP', 8),
(2, 'JAVA', 7),
(3, 'JQUERY', 8),
(4, 'JAVASCRIPT', 7);

-- --------------------------------------------------------

--
-- Table structure for table `doctor`
--

CREATE TABLE IF NOT EXISTS `doctor` (
  `doc_medical_no` int(11) NOT NULL,
  `doc_fname` varchar(50) DEFAULT NULL,
  `doc_lname` varchar(50) DEFAULT NULL,
  `doc_dob` varchar(15) DEFAULT NULL,
  `doc_email` varchar(25) DEFAULT NULL,
  `doc_mob` varchar(15) DEFAULT NULL,
  `doc_specialization` varchar(50) DEFAULT NULL,
  `doc_hospital` varchar(50) DEFAULT NULL,
  `doc_exp` int(11) DEFAULT NULL,
  `created_on` varchar(50) DEFAULT NULL,
  `created_by` varchar(50) DEFAULT NULL,
  `updated_by` varchar(50) DEFAULT NULL,
  `updated_on` varchar(50) DEFAULT NULL,
  `custom0` varchar(50) DEFAULT NULL,
  `custom1` varchar(50) DEFAULT NULL,
  `custom2` int(11) DEFAULT NULL,
  PRIMARY KEY (`doc_medical_no`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `doctor`
--

INSERT INTO `doctor` (`doc_medical_no`, `doc_fname`, `doc_lname`, `doc_dob`, `doc_email`, `doc_mob`, `doc_specialization`, `doc_hospital`, `doc_exp`, `created_on`, `created_by`, `updated_by`, `updated_on`, `custom0`, `custom1`, `custom2`) VALUES
(1234, 'Geetha ', 'Raman', NULL, 'geetha@gmail.com', '96358421665', 'Neurologist', 'FrontLine', 15, NULL, NULL, NULL, NULL, 'welcome', NULL, NULL),
(1256, 'Sengutuvan', NULL, NULL, 'sengutuvan@gmail.com', '9087654321', 'pediatrician', 'KMC', 20, NULL, NULL, NULL, NULL, 'welcome', NULL, NULL),
(5678, 'Senthil', 'Kumar', NULL, 'senthilkumar@gmail.com', '9003972720', 'Heart Specialist', 'APPOLO', 15, NULL, NULL, NULL, NULL, 'welcome', NULL, NULL),
(9012, 'Ganapathi', 'Sundharam', NULL, 'gsundaram@gmail.com', '9003976767', 'Skin Specialist', 'Own Clininc', 10, NULL, NULL, NULL, NULL, 'welcome', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `patient_login`
--

CREATE TABLE IF NOT EXISTS `patient_login` (
  `aadhar_num` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `created_on` varchar(50) DEFAULT NULL,
  `created_by` varchar(50) DEFAULT NULL,
  `updated_on` varchar(50) DEFAULT NULL,
  `updated_by` varchar(50) DEFAULT NULL,
  `custom0` varchar(50) DEFAULT NULL,
  `custom1` varchar(50) DEFAULT NULL,
  `custom2` varchar(50) DEFAULT NULL,
  `custom3` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `patient_login`
--

INSERT INTO `patient_login` (`aadhar_num`, `password`, `created_on`, `created_by`, `updated_on`, `updated_by`, `custom0`, `custom1`, `custom2`, `custom3`) VALUES
('1234567856781234', 'welcome', NULL, NULL, NULL, NULL, 'Swetha', NULL, NULL, NULL),
('5678123412345678', 'welcome', NULL, NULL, NULL, NULL, 'SubaSri', NULL, NULL, NULL);
