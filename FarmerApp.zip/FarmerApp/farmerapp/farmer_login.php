<?php
include("config.php");
session_start();
$aadhar_num=$_POST["username"];
$pass=$_POST["password"];
$sql = "SELECT * from login  where aadhar_num='".$aadhar_num."' && password='".$pass."' && usertype='F' ";
	$result = mysqli_query($db,$sql);
      $row = mysqli_fetch_array($result,MYSQLI_ASSOC);
     
     
      $count = mysqli_num_rows($result);
      
      // If result matched $myusername and $mypassword, table row must be 1 row
	//echo $sql;
      if($count == 1) {
//echo  $aadhar_num;
        // session_register("myusername");
         $_SESSION['login_user'] = $aadhar_num;
         
       header("location: farmerindex.html?ut=f");
      }else {
        header("location: farmerlogin.html");

      }


?>