<?php
include("config.php");
session_start();
//$aadhar_num=$_REQUEST["aano"];
$patient_id=$_REQUEST["patient_id"];
$doc_id=$_REQUEST["doc_id"];

//$sql = "insert into appointment  values('','".$doc_id."' , '".$aadhar_num."','NA','".$comments."',NULL,NULL,NULL,NULL,NULL)";
$sql="update appointment set appointment_status='A' where patient_id='".$patient_id."' and doc_id='".$doc_id."'";
$result = mysqli_query($db,$sql);
if($result)
{
  //header("location: success.html");
$posts[] = array('status' => '1');

}
else
{
 // header("location: failure.html");
$posts[] = array('status' => '0');

}
echo json_encode($posts);
?>