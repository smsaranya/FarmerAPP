-- phpMyAdmin SQL Dump
-- version 2.11.9.2
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jan 05, 2018 at 06:35 AM
-- Server version: 5.0.67
-- PHP Version: 5.2.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `healthmonitoring`
--

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE IF NOT EXISTS `login` (
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `aadhar_num` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `mobilenum` varchar(100) NOT NULL,
  `usertype` varchar(100) NOT NULL,
  `created_by` varchar(100) default NULL,
  `created_on` datetime default NULL,
  `updated_by` varchar(100) default NULL,
  `updated_on` datetime default NULL,
  `custom0` varchar(100) default NULL,
  `custom1` varchar(100) default NULL,
  `custom2` varchar(100) default NULL,
  `custom3` varchar(100) default NULL,
  `custom4` varchar(100) default NULL,
  PRIMARY KEY  (`aadhar_num`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`name`, `email`, `aadhar_num`, `password`, `mobilenum`, `usertype`, `created_by`, `created_on`, `updated_by`, `updated_on`, `custom0`, `custom1`, `custom2`, `custom3`, `custom4`) VALUES
('Jeeva', 'jeeva@gmail.com', '1234567856781234', 'welcome', '9112345687', 'F', NULL, '2018-01-05 09:27:52', NULL, '2018-01-05 09:27:52', NULL, NULL, NULL, NULL, NULL),
('Suresh Babu', 'sureshbabu@gmail.com', '1111222233334444', 'welcome', '9876543210', 'B', NULL, '2018-01-05 09:29:31', NULL, '2018-01-05 09:29:31', NULL, NULL, NULL, NULL, NULL),
('Saranya', 'saranya@gmail.com', '999988887776666', 'welcome', '9856742135', 'B', NULL, '2018-01-05 11:46:54', NULL, '2018-01-05 11:46:54', NULL, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE IF NOT EXISTS `product` (
  `pid` int(11) NOT NULL auto_increment,
  `pname` varchar(100) NOT NULL,
  `pprice` varchar(100) NOT NULL,
  `pqty` varchar(100) NOT NULL,
  `pauthor` varchar(100) NOT NULL,
  `created_by` varchar(100) NOT NULL,
  `created_on` datetime NOT NULL,
  `updated_by` varchar(100) NOT NULL,
  `updated_on` datetime NOT NULL,
  `custom0` varchar(100) NOT NULL,
  PRIMARY KEY  (`pid`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`pid`, `pname`, `pprice`, `pqty`, `pauthor`, `created_by`, `created_on`, `updated_by`, `updated_on`, `custom0`) VALUES
(1, 'carrot', '100', '0', '1234567856781234', '', '0000-00-00 00:00:00', '', '0000-00-00 00:00:00', ''),
(3, 'oil', '78', '78', '1234567856781234', '', '0000-00-00 00:00:00', '', '0000-00-00 00:00:00', ''),
(4, 'Rice', '50', '89', '1234567856781234', '', '0000-00-00 00:00:00', '', '0000-00-00 00:00:00', '');

-- --------------------------------------------------------

--
-- Table structure for table `purchase`
--

CREATE TABLE IF NOT EXISTS `purchase` (
  `pid` int(11) default NULL,
  `qty` varchar(100) NOT NULL,
  `aadhar_num` varchar(100) NOT NULL,
  `created_by` varchar(100) default NULL,
  `created_on` datetime default NULL,
  `updated_by` varchar(100) default NULL,
  `updated_on` datetime default NULL,
  `custom0` varchar(100) default NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `purchase`
--

